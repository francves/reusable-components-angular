export * from './lib/random-heroes.service';
export * from './lib/random-heroes.component';
export * from './lib/random-heroes.module';
//# sourceMappingURL=public-api.d.ts.map