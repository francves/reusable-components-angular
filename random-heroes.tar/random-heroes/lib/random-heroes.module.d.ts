import * as i0 from "@angular/core";
import * as i1 from "./random-heroes.component";
export declare class RandomHeroesModule {
    static ɵfac: i0.ɵɵFactoryDef<RandomHeroesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDefWithMeta<RandomHeroesModule, [typeof i1.RandomHeroesComponent], never, [typeof i1.RandomHeroesComponent]>;
    static ɵinj: i0.ɵɵInjectorDef<RandomHeroesModule>;
}
//# sourceMappingURL=random-heroes.module.d.ts.map