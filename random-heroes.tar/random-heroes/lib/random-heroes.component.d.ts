import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class RandomHeroesComponent implements OnInit {
    constructor();
    heroes: {
        name: string;
        url: string;
    }[];
    randomHeroe: {
        name: string;
        url: string;
    };
    ngOnInit(): void;
    refreshRandomHeroes(): void;
    static ɵfac: i0.ɵɵFactoryDef<RandomHeroesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDefWithMeta<RandomHeroesComponent, "lib-random-heroes", never, {}, {}, never, never>;
}
//# sourceMappingURL=random-heroes.component.d.ts.map