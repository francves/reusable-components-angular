import * as i0 from "@angular/core";
export declare class RandomHeroesService {
    constructor();
    static ɵfac: i0.ɵɵFactoryDef<RandomHeroesService, never>;
    static ɵprov: i0.ɵɵInjectableDef<RandomHeroesService>;
}
//# sourceMappingURL=random-heroes.service.d.ts.map