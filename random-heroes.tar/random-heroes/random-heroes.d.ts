/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="random-heroes" />
export * from './public-api';
//# sourceMappingURL=random-heroes.d.ts.map