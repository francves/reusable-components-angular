(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core')) :
    typeof define === 'function' && define.amd ? define('random-heroes', ['exports', '@angular/core'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global['random-heroes'] = {}, global.ng.core));
}(this, (function (exports, i0) { 'use strict';

    var RandomHeroesService = /** @class */ (function () {
        function RandomHeroesService() {
        }
        return RandomHeroesService;
    }());
    RandomHeroesService.ɵfac = function RandomHeroesService_Factory(t) { return new (t || RandomHeroesService)(); };
    RandomHeroesService.ɵprov = i0.ɵɵdefineInjectable({ token: RandomHeroesService, factory: RandomHeroesService.ɵfac, providedIn: 'root' });
    (function () {
        (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RandomHeroesService, [{
                type: i0.Injectable,
                args: [{
                        providedIn: 'root'
                    }]
            }], function () { return []; }, null);
    })();

    var RandomHeroesComponent = /** @class */ (function () {
        function RandomHeroesComponent() {
            this.heroes = [
                {
                    name: "Blackwidow",
                    url: "/assets/img/blackwidow.jpg"
                },
                {
                    name: "Cap",
                    url: "/assets/img/cap.jpg"
                },
                {
                    name: "Fury",
                    url: "/assets/img/fury.jpg"
                },
                {
                    name: "Ironman",
                    url: "/assets/img/ironman.jpg"
                },
                {
                    name: "Thor",
                    url: "/assets/img/thor.jpg"
                }
            ];
            this.randomHeroe = { name: '', url: '' };
        }
        RandomHeroesComponent.prototype.ngOnInit = function () {
            this.refreshRandomHeroes();
        };
        RandomHeroesComponent.prototype.refreshRandomHeroes = function () {
            var randomNumber = Math.floor(Math.random() * 6);
            this.randomHeroe = this.heroes[randomNumber];
        };
        return RandomHeroesComponent;
    }());
    RandomHeroesComponent.ɵfac = function RandomHeroesComponent_Factory(t) { return new (t || RandomHeroesComponent)(); };
    RandomHeroesComponent.ɵcmp = i0.ɵɵdefineComponent({ type: RandomHeroesComponent, selectors: [["lib-random-heroes"]], decls: 6, vars: 2, consts: [[1, "container"], ["alt", "random heroe", 3, "src"], [3, "click"]], template: function RandomHeroesComponent_Template(rf, ctx) {
            if (rf & 1) {
                i0.ɵɵelementStart(0, "div", 0);
                i0.ɵɵelement(1, "img", 1);
                i0.ɵɵelementStart(2, "h2");
                i0.ɵɵtext(3);
                i0.ɵɵelementEnd();
                i0.ɵɵelementStart(4, "button", 2);
                i0.ɵɵlistener("click", function RandomHeroesComponent_Template_button_click_4_listener() { return ctx.refreshRandomHeroes(); });
                i0.ɵɵtext(5, "Refrescar");
                i0.ɵɵelementEnd();
                i0.ɵɵelementEnd();
            }
            if (rf & 2) {
                i0.ɵɵadvance(1);
                i0.ɵɵpropertyInterpolate("src", ctx.randomHeroe.url, i0.ɵɵsanitizeUrl);
                i0.ɵɵadvance(2);
                i0.ɵɵtextInterpolate1("Nombre: ", ctx.randomHeroe.name, "");
            }
        }, styles: [".container[_ngcontent-%COMP%]{margin:40px auto}.container[_ngcontent-%COMP%], .container[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]{max-width:300px}"] });
    (function () {
        (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RandomHeroesComponent, [{
                type: i0.Component,
                args: [{
                        selector: 'lib-random-heroes',
                        templateUrl: './random-hero.component.html',
                        styleUrls: ['./random-hero.component.scss']
                    }]
            }], function () { return []; }, null);
    })();

    var RandomHeroesModule = /** @class */ (function () {
        function RandomHeroesModule() {
        }
        return RandomHeroesModule;
    }());
    RandomHeroesModule.ɵfac = function RandomHeroesModule_Factory(t) { return new (t || RandomHeroesModule)(); };
    RandomHeroesModule.ɵmod = i0.ɵɵdefineNgModule({ type: RandomHeroesModule });
    RandomHeroesModule.ɵinj = i0.ɵɵdefineInjector({ imports: [[]] });
    (function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(RandomHeroesModule, { declarations: [RandomHeroesComponent], exports: [RandomHeroesComponent] }); })();
    (function () {
        (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(RandomHeroesModule, [{
                type: i0.NgModule,
                args: [{
                        declarations: [RandomHeroesComponent],
                        imports: [],
                        exports: [RandomHeroesComponent]
                    }]
            }], null, null);
    })();

    /*
     * Public API Surface of random-heroes
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.RandomHeroesComponent = RandomHeroesComponent;
    exports.RandomHeroesModule = RandomHeroesModule;
    exports.RandomHeroesService = RandomHeroesService;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=random-heroes.umd.js.map
