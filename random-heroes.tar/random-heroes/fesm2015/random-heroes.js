import { ɵɵdefineInjectable, ɵsetClassMetadata, Injectable, ɵɵdefineComponent, ɵɵelementStart, ɵɵelement, ɵɵtext, ɵɵelementEnd, ɵɵlistener, ɵɵadvance, ɵɵpropertyInterpolate, ɵɵsanitizeUrl, ɵɵtextInterpolate1, Component, ɵɵdefineNgModule, ɵɵdefineInjector, ɵɵsetNgModuleScope, NgModule } from '@angular/core';

class RandomHeroesService {
    constructor() { }
}
RandomHeroesService.ɵfac = function RandomHeroesService_Factory(t) { return new (t || RandomHeroesService)(); };
RandomHeroesService.ɵprov = ɵɵdefineInjectable({ token: RandomHeroesService, factory: RandomHeroesService.ɵfac, providedIn: 'root' });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && ɵsetClassMetadata(RandomHeroesService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], function () { return []; }, null); })();

class RandomHeroesComponent {
    constructor() {
        this.heroes = [
            {
                name: "Blackwidow",
                url: "/assets/img/blackwidow.jpg"
            },
            {
                name: "Cap",
                url: "/assets/img/cap.jpg"
            },
            {
                name: "Fury",
                url: "/assets/img/fury.jpg"
            },
            {
                name: "Ironman",
                url: "/assets/img/ironman.jpg"
            },
            {
                name: "Thor",
                url: "/assets/img/thor.jpg"
            }
        ];
        this.randomHeroe = { name: '', url: '' };
    }
    ngOnInit() {
        this.refreshRandomHeroes();
    }
    refreshRandomHeroes() {
        let randomNumber = Math.floor(Math.random() * 6);
        this.randomHeroe = this.heroes[randomNumber];
    }
}
RandomHeroesComponent.ɵfac = function RandomHeroesComponent_Factory(t) { return new (t || RandomHeroesComponent)(); };
RandomHeroesComponent.ɵcmp = ɵɵdefineComponent({ type: RandomHeroesComponent, selectors: [["lib-random-heroes"]], decls: 6, vars: 2, consts: [[1, "container"], ["alt", "random heroe", 3, "src"], [3, "click"]], template: function RandomHeroesComponent_Template(rf, ctx) { if (rf & 1) {
        ɵɵelementStart(0, "div", 0);
        ɵɵelement(1, "img", 1);
        ɵɵelementStart(2, "h2");
        ɵɵtext(3);
        ɵɵelementEnd();
        ɵɵelementStart(4, "button", 2);
        ɵɵlistener("click", function RandomHeroesComponent_Template_button_click_4_listener() { return ctx.refreshRandomHeroes(); });
        ɵɵtext(5, "Refrescar");
        ɵɵelementEnd();
        ɵɵelementEnd();
    } if (rf & 2) {
        ɵɵadvance(1);
        ɵɵpropertyInterpolate("src", ctx.randomHeroe.url, ɵɵsanitizeUrl);
        ɵɵadvance(2);
        ɵɵtextInterpolate1("Nombre: ", ctx.randomHeroe.name, "");
    } }, styles: [".container[_ngcontent-%COMP%]{margin:40px auto}.container[_ngcontent-%COMP%], .container[_ngcontent-%COMP%]   img[_ngcontent-%COMP%]{max-width:300px}"] });
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && ɵsetClassMetadata(RandomHeroesComponent, [{
        type: Component,
        args: [{
                selector: 'lib-random-heroes',
                templateUrl: './random-hero.component.html',
                styleUrls: ['./random-hero.component.scss']
            }]
    }], function () { return []; }, null); })();

class RandomHeroesModule {
}
RandomHeroesModule.ɵfac = function RandomHeroesModule_Factory(t) { return new (t || RandomHeroesModule)(); };
RandomHeroesModule.ɵmod = ɵɵdefineNgModule({ type: RandomHeroesModule });
RandomHeroesModule.ɵinj = ɵɵdefineInjector({ imports: [[]] });
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && ɵɵsetNgModuleScope(RandomHeroesModule, { declarations: [RandomHeroesComponent], exports: [RandomHeroesComponent] }); })();
(function () { (typeof ngDevMode === "undefined" || ngDevMode) && ɵsetClassMetadata(RandomHeroesModule, [{
        type: NgModule,
        args: [{
                declarations: [RandomHeroesComponent],
                imports: [],
                exports: [RandomHeroesComponent]
            }]
    }], null, null); })();

/*
 * Public API Surface of random-heroes
 */

/**
 * Generated bundle index. Do not edit.
 */

export { RandomHeroesComponent, RandomHeroesModule, RandomHeroesService };
//# sourceMappingURL=random-heroes.js.map
